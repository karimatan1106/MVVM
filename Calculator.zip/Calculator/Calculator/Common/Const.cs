﻿namespace Calculator.Common
{
    internal class Const
    {
        #region 定数

        internal const string NaN = "NaN";
        internal const string Error = "Error";

        #endregion
    }
}
