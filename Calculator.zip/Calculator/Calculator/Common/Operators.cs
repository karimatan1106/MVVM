﻿namespace Calculator.Common
{
    internal static class Operators
    {
        #region 定数

        internal const string Plus = "+";
        internal const string Minus = "-";
        internal const string Multiplied = "*";
        internal const string Divided = "/";
        internal const string AllOperators = "+-*/";

        #endregion

        #region メソッド

        internal static bool IsOperators(string value)
        {
            return value == Plus
                   || value == Minus
                   || value == Multiplied
                   || value == Divided;
        }

        #endregion


    }
}
