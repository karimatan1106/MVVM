﻿using System.Data;
using System.Windows.Input;
using Calculator.BasePage;
using Calculator.Common;
using System.Linq;

namespace Calculator.ViewModel
{
    internal class MainViewModel : ViewModelBase
    {
        #region メンバ変数

        private string _formula = "0";
        private string _preFormula;
        private string _inputFormula;
        private readonly DataTable _dt = new DataTable();

        #endregion

        #region プロパティ

        public string Formula
        {
            get { return _formula; }
            set
            {
                this._formula = value;
                this.OnPropertyChanged("Formula");
            }
        }

        public string PreFormula
        {
            get { return _preFormula; }
            set
            {
                this._preFormula = value;
                this.OnPropertyChanged("PreFormula");
            }
        }

        public string InputFormula
        {
            set
            {
                this.Formula = value;
            }
        }

        public ICommand OnClickZero { get; }
        public ICommand OnClickOne { get; }
        public ICommand OnClickTwo { get; }
        public ICommand OnClickThree { get; }
        public ICommand OnClickFour { get; }
        public ICommand OnClickFive { get; }
        public ICommand OnClickSix { get; }
        public ICommand OnClickSeven { get; }
        public ICommand OnClickEight { get; }
        public ICommand OnClickNine { get; }
        public ICommand OnClickComma { get; }
        public ICommand OnClickPlus { get; }
        public ICommand OnClickMinus { get; }
        public ICommand OnClickMultiplied { get; }
        public ICommand OnClickDivided { get; }
        public ICommand OnClickEqual { get; }
        public ICommand OnPushEscape { get; }

        #endregion

        #region コンストラクタ

        internal MainViewModel()
        {
            OnClickZero = new InputCommand(() => SetFormula("0"));
            OnClickOne = new InputCommand(() => SetFormula("1"));
            OnClickTwo = new InputCommand(() => SetFormula("2"));
            OnClickThree = new InputCommand(() => SetFormula("3"));
            OnClickFour = new InputCommand(() => SetFormula("4"));
            OnClickFive = new InputCommand(() => SetFormula("5"));
            OnClickSix = new InputCommand(() => SetFormula("6"));
            OnClickSeven = new InputCommand(() => SetFormula("7"));
            OnClickEight = new InputCommand(() => SetFormula("8"));
            OnClickNine = new InputCommand(() => SetFormula("9"));
            OnClickComma = new InputCommand(() => SetFormula("."));
            OnClickPlus = new InputCommand(() => SetFormula(Operators.Plus));
            OnClickMinus = new InputCommand(() => SetFormula(Operators.Minus));
            OnClickMultiplied = new InputCommand(() => SetFormula(Operators.Multiplied));
            OnClickDivided = new InputCommand(() => SetFormula(Operators.Divided));
            OnClickEqual = new InputCommand(CalcFormula);
            OnPushEscape = new InputCommand(ClearFormula);
        }

        #endregion

        #region メソッド

        /// <summary>
        /// 入力した値を式にセット
        /// </summary>
        /// <param name="value"></param>
        private void SetFormula(string value)
        {
            //前回の計算結果が値でない場合はクリア
            if (this.Formula == Const.Error
                || this.Formula == Const.NaN)
            {
                ClearFormula();
            }

            if (value == ".")
            {
                var currentSection = this.Formula.Split(Operators.AllOperators.ToCharArray()).Last();
                if (!currentSection.Contains(".")) this.Formula += ".";
            }
            else if (Operators.IsOperators(value))
            {
                if (this.Formula.TrimEnd(' ') == string.Empty) this.Formula = "0";

                var lastChar = this.Formula.TrimEnd(' ').Last();
                if (!Operators.IsOperators(lastChar.ToString()))
                {
                    this.Formula += $" {value} ";
                }
                else if (Operators.Minus != lastChar.ToString()
                         && Operators.Minus == value)
                {
                    this.Formula += $" {Operators.Minus} ";
                }
            }
            else this.Formula = (this.Formula == "0") ? value : this.Formula += value;
        }

        /// <summary>
        /// 入力された値の計算
        /// </summary>
        private void CalcFormula()
        {
            try
            {
                this.PreFormula = $"{this.Formula} =";
                this.Formula = _dt.Compute(this.Formula, string.Empty).ToString();
            }
            catch
            {
                this.Formula = "Error";
            }
        }

        /// <summary>
        /// 計算式のクリア
        /// </summary>
        private void ClearFormula()
        {
            this.Formula = "0";
        }

        #endregion
    }
}
