﻿using System.Windows;
using Calculator.ViewModel;

namespace Calculator
{
    public partial class MainWindow : Window
    {
        #region コンストラクタ

        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new MainViewModel();
        }

        #endregion
    }
}
